const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../config/db');
const { authenticateToken, requireModule } = require('../middleware/auth');

const router = express.Router();

router.get('/', authenticateToken, requireModule('users'), async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT u.id, u.username, u.full_name, u.role, u.employee_id, u.allowed_modules, u.is_active, e.emp_code
            FROM users u
            LEFT JOIN employees e ON u.employee_id = e.id
            ORDER BY u.id ASC
        `);
        const formatted = rows.map(u => ({
            ...u,
            allowed_modules: typeof u.allowed_modules === 'string' ? JSON.parse(u.allowed_modules) : u.allowed_modules
        }));
        res.json(formatted);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/', authenticateToken, requireModule('users'), async (req, res) => {
    const { username, password, full_name, role, employee_id, allowed_modules } = req.body;
    try {
        const hash = await bcrypt.hash(password, 10);
        const modules = role === 'EMPLOYEE' ? ['employee_portal'] : allowed_modules;
        await db.query(
            'INSERT INTO users (username, password_hash, full_name, role, employee_id, allowed_modules) VALUES (?, ?, ?, ?, ?, ?)',
            [username, hash, full_name, role, employee_id || null, JSON.stringify(modules)]
        );
        res.status(201).json({ message: 'User account created successfully' });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

module.exports = router;