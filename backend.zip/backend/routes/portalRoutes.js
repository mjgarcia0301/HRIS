const express = require('express');
const db = require('../config/db');
const { authenticateToken, requireModule } = require('../middleware/auth');

const router = express.Router();

// Employee: View strictly their own payslips
router.get('/my-payslips', authenticateToken, requireModule('employee_portal'), async (req, res) => {
    try {
        if (!req.user.employee_id) {
            return res.status(400).json({ message: 'No employee profile linked to this account.' });
        }
        const [rows] = await db.query(`
            SELECT p.*, e.emp_code, e.first_name, e.last_name, e.department, e.position,
                   e.sss_no, e.pagibig_no, e.philhealth_no, e.tin_no, pp.period_name
            FROM payslips p
            JOIN employees e ON p.employee_id = e.id
            JOIN pay_periods pp ON p.pay_period_id = pp.id
            WHERE p.employee_id = ?
            ORDER BY pp.start_date DESC
        `, [req.user.employee_id]);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Employee & HR: View company memos & compliance items
router.get('/memos', authenticateToken, async (req, res) => {
    try {
        const empId = req.user.employee_id || 0;
        const [rows] = await db.query(`
            SELECT m.*, u.full_name AS author_name, ma.acknowledged_at
            FROM company_memos m
            JOIN users u ON m.posted_by = u.id
            LEFT JOIN memo_acknowledgments ma 
                ON m.id = ma.memo_id AND ma.employee_id = ?
            ORDER BY m.created_at DESC
        `, [empId]);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Employee: Acknowledge / Comply with a memo
router.post('/memos/:memoId/acknowledge', authenticateToken, requireModule('employee_portal'), async (req, res) => {
    try {
        if (!req.user.employee_id) {
            return res.status(400).json({ message: 'No employee profile linked.' });
        }
        await db.query(
            'INSERT IGNORE INTO memo_acknowledgments (memo_id, employee_id) VALUES (?, ?)',
            [req.params.memoId, req.user.employee_id]
        );
        res.json({ message: 'Compliance acknowledged.' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// HR / Admin: Publish a new memo or compliance requirement
router.post('/memos', authenticateToken, requireModule('memos_manage'), async (req, res) => {
    const { title, category, content, due_date } = req.body;
    try {
        await db.query(
            'INSERT INTO company_memos (title, category, content, due_date, posted_by) VALUES (?, ?, ?, ?, ?)',
            [title, category, content, due_date || null, req.user.id]
        );
        res.status(201).json({ message: 'Memo published to all employees.' });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

module.exports = router;