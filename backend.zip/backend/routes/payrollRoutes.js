const express = require('express');
const multer = require('multer');
const csv = require('csv-parser');
const fs = require('fs');
const db = require('../config/db');
const { authenticateToken, requireModule } = require('../middleware/auth');
const { computePayroll } = require('../utils/payrollCalculator');

const router = express.Router();
const upload = multer({ dest: 'uploads/' });

router.get('/periods', authenticateToken, async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM pay_periods ORDER BY id DESC');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/periods', authenticateToken, requireModule('payroll'), async (req, res) => {
    const { period_name, start_date, end_date } = req.body;
    try {
        await db.query('INSERT INTO pay_periods (period_name, start_date, end_date) VALUES (?, ?, ?)', [period_name, start_date, end_date]);
        res.status(201).json({ message: 'Pay period created' });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

router.post('/upload-timesheet', authenticateToken, requireModule('payroll'), upload.single('timesheet'), (req, res) => {
    const { pay_period_id } = req.body;
    if (!req.file) return res.status(400).json({ message: 'CSV file is required' });

    const rows = [];
    fs.createReadStream(req.file.path)
        .pipe(csv())
        .on('data', (data) => rows.push(data))
        .on('end', async () => {
            fs.unlinkSync(req.file.path);
            const conn = await db.getConnection();
            let processedCount = 0;

            try {
                await conn.beginTransaction();
                await conn.query('DELETE FROM timesheets WHERE pay_period_id = ?', [pay_period_id]);
                await conn.query('DELETE FROM payslips WHERE pay_period_id = ?', [pay_period_id]);

                for (const row of rows) {
                    const empCode = (row.emp_code || '').trim();
                    if (!empCode) continue;

                    const regHours = parseFloat(row.regular_hours || 0);
                    const otHours = parseFloat(row.overtime_hours || 0);
                    const lateMins = parseInt(row.late_minutes || 0, 10);

                    const [empRows] = await conn.query('SELECT * FROM employees WHERE emp_code = ? AND status = "ACTIVE"', [empCode]);
                    if (empRows.length === 0) continue;
                    const emp = empRows[0];

                    await conn.query(
                        'INSERT INTO timesheets (pay_period_id, emp_code, regular_hours, overtime_hours, late_minutes, uploaded_by) VALUES (?, ?, ?, ?, ?, ?)',
                        [pay_period_id, empCode, regHours, otHours, lateMins, req.user.id]
                    );

                    const calc = computePayroll({
                        basicMonthlySalary: parseFloat(emp.basic_monthly_salary),
                        hourlyRate: parseFloat(emp.hourly_rate),
                        regularHours: regHours,
                        overtimeHours: otHours,
                        lateMinutes: lateMins
                    });

                    await conn.query(
                        `INSERT INTO payslips 
                        (pay_period_id, employee_id, regular_hours, overtime_hours, late_minutes, regular_pay, overtime_pay, gross_pay, sss_deduction, pagibig_deduction, philhealth_deduction, withholding_tax, late_deduction, total_deductions, net_pay)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                        [
                            pay_period_id, emp.id, regHours, otHours, lateMins,
                            calc.regular_pay, calc.overtime_pay, calc.gross_pay,
                            calc.sss_deduction, calc.pagibig_deduction, calc.philhealth_deduction,
                            calc.withholding_tax, calc.late_deduction, calc.total_deductions, calc.net_pay
                        ]
                    );
                    processedCount++;
                }

                await conn.query('UPDATE pay_periods SET status = "PROCESSED" WHERE id = ?', [pay_period_id]);
                await conn.commit();
                res.json({ message: `Successfully processed ${processedCount} employee payslips!` });
            } catch (err) {
                await conn.rollback();
                res.status(500).json({ error: err.message });
            } finally {
                conn.release();
            }
        });
});

router.get('/payslips/:periodId', authenticateToken, requireModule('payslips'), async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT p.*, e.emp_code, e.first_name, e.last_name, e.department, e.position, e.sss_no, e.pagibig_no, e.philhealth_no, e.tin_no, pp.period_name
            FROM payslips p
            JOIN employees e ON p.employee_id = e.id
            JOIN pay_periods pp ON p.pay_period_id = pp.id
            WHERE p.pay_period_id = ?
            ORDER BY e.emp_code ASC
        `, [req.params.periodId]);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;