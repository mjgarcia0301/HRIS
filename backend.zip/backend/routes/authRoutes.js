const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/db');

const router = express.Router();

router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const [rows] = await db.query('SELECT * FROM users WHERE username = ? AND is_active = TRUE', [username]);
        if (rows.length === 0) return res.status(401).json({ message: 'Invalid username or inactive account' });

        const user = rows[0];
        const validPassword = await bcrypt.compare(password, user.password_hash);
        if (!validPassword) return res.status(401).json({ message: 'Invalid password' });

        const allowedModules = typeof user.allowed_modules === 'string'
            ? JSON.parse(user.allowed_modules)
            : user.allowed_modules;

        const payload = {
            id: user.id,
            username: user.username,
            full_name: user.full_name,
            role: user.role,
            employee_id: user.employee_id,
            allowed_modules: allowedModules
        };

        const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '12h' });
        res.json({ token, user: payload });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;