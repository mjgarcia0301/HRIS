const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../config/db');
const { authenticateToken, requireModule } = require('../middleware/auth');

const router = express.Router();

router.get('/', authenticateToken, requireModule('employees'), async (req, res) => {
    try {
        const [rows] = await db.query(
            'SELECT id, emp_code, first_name, last_name, email, department, position, basic_monthly_salary, hourly_rate, sss_no, pagibig_no, philhealth_no, tin_no, status FROM employees ORDER BY emp_code ASC'
        );
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/', authenticateToken, requireModule('employees'), async (req, res) => {
    const {
        emp_code, first_name, last_name, email, department, position,
        basic_monthly_salary, sss_no, pagibig_no, philhealth_no, tin_no, clock_password
    } = req.body;

    const hourly_rate = (parseFloat(basic_monthly_salary) / 176).toFixed(2);
    const clockHash = await bcrypt.hash(clock_password || '123456', 10);

    try {
        await db.query(
            `INSERT INTO employees (emp_code, first_name, last_name, email, department, position, basic_monthly_salary, hourly_rate, sss_no, pagibig_no, philhealth_no, tin_no, clock_password_hash)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [emp_code.trim().toUpperCase(), first_name, last_name, email, department, position, basic_monthly_salary, hourly_rate, sss_no, pagibig_no, philhealth_no, tin_no, clockHash]
        );
        res.status(201).json({ message: 'Employee added successfully (Default clock password: ' + (clock_password || '123456') + ')' });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

module.exports = router;