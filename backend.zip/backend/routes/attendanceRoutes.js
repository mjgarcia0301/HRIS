const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../config/db');
const { authenticateToken, requireModule } = require('../middleware/auth');
const { computePayroll } = require('../utils/payrollCalculator');

const router = express.Router();

// Helper: Calculate regular hours, overtime hours, and late minutes for a shift
// Standard shift: 08:00 AM start, 8 regular hours/day (1 hr unpaid lunch deducted if shift > 5 hrs)
function calculateShiftMetrics(timeInDate, timeOutDate) {
    const shiftStart = new Date(timeInDate);
    shiftStart.setHours(8, 0, 0, 0);

    // Late minutes if clocked in after 8:00 AM
    let lateMinutes = 0;
    if (timeInDate > shiftStart) {
        lateMinutes = Math.floor((timeInDate - shiftStart) / 60000);
    }

    // Total worked hours
    const diffMs = Math.max(0, timeOutDate - timeInDate);
    let totalHours = diffMs / (1000 * 60 * 60);
    if (totalHours > 5) totalHours -= 1; // Deduct 1-hour lunch break

    const regularHours = Math.min(8, Math.max(0, totalHours));
    const overtimeHours = Math.max(0, totalHours - 8);

    return {
        regular_hours: Number(regularHours.toFixed(2)),
        overtime_hours: Number(overtimeHours.toFixed(2)),
        late_minutes: lateMinutes
    };
}

// ==========================================
// 1. KIOSK PUNCH: TIME IN OR TIME OUT (Employee Number + Password)
// ==========================================
router.post('/punch', async (req, res) => {
    const { emp_code, password, action } = req.body; // action: 'IN' or 'OUT'
    if (!emp_code || !password || !action) {
        return res.status(400).json({ message: 'Employee number, password, and action are required.' });
    }

    try {
        const [empRows] = await db.query(
            'SELECT * FROM employees WHERE emp_code = ? AND status = "ACTIVE"',
            [emp_code.trim().toUpperCase()]
        );
        if (empRows.length === 0) {
            return res.status(404).json({ message: 'Employee number not found or inactive.' });
        }

        const emp = empRows[0];
        if (!emp.clock_password_hash) {
            return res.status(400).json({ message: 'Clock password not set for this employee. Contact HR.' });
        }

        const validPass = await bcrypt.compare(password, emp.clock_password_hash);
        if (!validPass) {
            return res.status(401).json({ message: 'Invalid password.' });
        }

        const now = new Date();
        const todayStr = now.toISOString().slice(0, 10);

        // Check if employee currently has an open shift
        const [openLogs] = await db.query(
            'SELECT * FROM attendance_logs WHERE employee_id = ? AND status = "CLOCKED_IN" ORDER BY id DESC LIMIT 1',
            [emp.id]
        );

        if (action === 'IN') {
            if (openLogs.length > 0) {
                return res.status(400).json({
                    message: `${emp.first_name} ${emp.last_name} is already clocked in since ${new Date(openLogs[0].time_in).toLocaleTimeString()}.`
                });
            }

            await db.query(
                'INSERT INTO attendance_logs (employee_id, emp_code, work_date, time_in, status) VALUES (?, ?, ?, ?, "CLOCKED_IN")',
                [emp.id, emp.emp_code, todayStr, now]
            );

            return res.json({
                message: `TIME IN recorded for ${emp.first_name} ${emp.last_name} (${emp.emp_code}) at ${now.toLocaleTimeString()}.`,
                employee: `${emp.first_name} ${emp.last_name}`,
                timestamp: now,
                type: 'IN'
            });
        }

        if (action === 'OUT') {
            if (openLogs.length === 0) {
                return res.status(400).json({
                    message: `No active Time-In found for ${emp.first_name} ${emp.last_name}. Please Time In first.`
                });
            }

            const activeLog = openLogs[0];
            const metrics = calculateShiftMetrics(new Date(activeLog.time_in), now);

            await db.query(
                `UPDATE attendance_logs 
                 SET time_out = ?, regular_hours = ?, overtime_hours = ?, late_minutes = ?, status = "COMPLETED" 
                 WHERE id = ?`,
                [now, metrics.regular_hours, metrics.overtime_hours, metrics.late_minutes, activeLog.id]
            );

            return res.json({
                message: `TIME OUT recorded for ${emp.first_name} ${emp.last_name} at ${now.toLocaleTimeString()} (Reg: ${metrics.regular_hours}h, OT: ${metrics.overtime_hours}h, Late: ${metrics.late_minutes}m).`,
                employee: `${emp.first_name} ${emp.last_name}`,
                timestamp: now,
                metrics,
                type: 'OUT'
            });
        }

        res.status(400).json({ message: 'Invalid punch action.' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Recent Kiosk Logs (for live feed on the Time Clock screen)
router.get('/recent', async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT a.*, e.first_name, e.last_name, e.department
            FROM attendance_logs a
            JOIN employees e ON a.employee_id = e.id
            ORDER BY a.id DESC LIMIT 15
        `);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ==========================================
// 2. PAYROLL OFFICER: GENERATE WHOLE TIME-IN / TIME-OUT RECORDS FOR PAY PERIOD
// ==========================================
router.get('/period-report/:periodId', authenticateToken, requireModule('payroll'), async (req, res) => {
    try {
        const [periodRows] = await db.query('SELECT * FROM pay_periods WHERE id = ?', [req.params.periodId]);
        if (periodRows.length === 0) return res.status(404).json({ message: 'Pay period not found' });

        const period = periodRows[0];

        // Detailed daily punches within the pay period dates
        const [detailedLogs] = await db.query(`
            SELECT a.*, e.first_name, e.last_name, e.department, e.position
            FROM attendance_logs a
            JOIN employees e ON a.employee_id = e.id
            WHERE a.work_date BETWEEN ? AND ?
            ORDER BY a.work_date ASC, e.emp_code ASC
        `, [period.start_date, period.end_date]);

        // Aggregated totals per employee (ready for payroll computation or CSV export)
        const [summary] = await db.query(`
            SELECT e.id AS employee_id, e.emp_code, e.first_name, e.last_name, e.department,
                   COALESCE(SUM(a.regular_hours), 0) AS regular_hours,
                   COALESCE(SUM(a.overtime_hours), 0) AS overtime_hours,
                   COALESCE(SUM(a.late_minutes), 0) AS late_minutes,
                   COUNT(a.id) AS days_logged
            FROM employees e
            LEFT JOIN attendance_logs a 
                ON e.id = a.employee_id 
                AND a.work_date BETWEEN ? AND ? 
                AND a.status = 'COMPLETED'
            WHERE e.status = 'ACTIVE'
            GROUP BY e.id, e.emp_code, e.first_name, e.last_name, e.department
            ORDER BY e.emp_code ASC
        `, [period.start_date, period.end_date]);

        res.json({ period, detailedLogs, summary });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ==========================================
// 3. PAYROLL OFFICER: AUTO-COMPUTE PAYROLL DIRECTLY FROM TIME-IN/OUT LOGS
// ==========================================
router.post('/process-from-logs/:periodId', authenticateToken, requireModule('payroll'), async (req, res) => {
    const periodId = req.params.periodId;
    const conn = await db.getConnection();

    try {
        const [periodRows] = await conn.query('SELECT * FROM pay_periods WHERE id = ?', [periodId]);
        if (periodRows.length === 0) {
            conn.release();
            return res.status(404).json({ message: 'Pay period not found' });
        }
        const period = periodRows[0];

        const [summary] = await conn.query(`
            SELECT e.*,
                   COALESCE(SUM(a.regular_hours), 0) AS total_reg_hours,
                   COALESCE(SUM(a.overtime_hours), 0) AS total_ot_hours,
                   COALESCE(SUM(a.late_minutes), 0) AS total_late_mins
            FROM employees e
            JOIN attendance_logs a 
                ON e.id = a.employee_id 
                AND a.work_date BETWEEN ? AND ? 
                AND a.status = 'COMPLETED'
            WHERE e.status = 'ACTIVE'
            GROUP BY e.id
        `, [period.start_date, period.end_date]);

        if (summary.length === 0) {
            conn.release();
            return res.status(400).json({ message: 'No completed Time-In/Time-Out records found within this pay period date range.' });
        }

        await conn.beginTransaction();
        await conn.query('DELETE FROM timesheets WHERE pay_period_id = ?', [periodId]);
        await conn.query('DELETE FROM payslips WHERE pay_period_id = ?', [periodId]);

        for (const emp of summary) {
            const regHours = parseFloat(emp.total_reg_hours);
            const otHours = parseFloat(emp.total_ot_hours);
            const lateMins = parseInt(emp.total_late_mins, 10);

            await conn.query(
                'INSERT INTO timesheets (pay_period_id, emp_code, regular_hours, overtime_hours, late_minutes, uploaded_by) VALUES (?, ?, ?, ?, ?, ?)',
                [periodId, emp.emp_code, regHours, otHours, lateMins, req.user.id]
            );

            const calc = computePayroll({
                basicMonthlySalary: parseFloat(emp.basic_monthly_salary),
                hourlyRate: parseFloat(emp.hourly_rate),
                regularHours: regHours,
                overtimeHours: otHours,
                lateMinutes: lateMins
            });

            await conn.query(
                `INSERT INTO payslips 
                (pay_period_id, employee_id, regular_hours, overtime_hours, late_minutes, regular_pay, overtime_pay, gross_pay, sss_deduction, pagibig_deduction, philhealth_deduction, withholding_tax, late_deduction, total_deductions, net_pay)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [
                    periodId, emp.id, regHours, otHours, lateMins,
                    calc.regular_pay, calc.overtime_pay, calc.gross_pay,
                    calc.sss_deduction, calc.pagibig_deduction, calc.philhealth_deduction,
                    calc.withholding_tax, calc.late_deduction, calc.total_deductions, calc.net_pay
                ]
            );
        }

        await conn.query('UPDATE pay_periods SET status = "PROCESSED" WHERE id = ?', [periodId]);
        await conn.commit();
        res.json({ message: `Auto-computed payroll & generated ${summary.length} payslips directly from Time-In/Out records!` });
    } catch (err) {
        await conn.rollback();
        res.status(500).json({ error: err.message });
    } finally {
        conn.release();
    }
});

module.exports = router;