const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const fs = require('fs');
require('dotenv').config();

const db = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const employeeRoutes = require('./routes/employeeRoutes');
const payrollRoutes = require('./routes/payrollRoutes');
const portalRoutes = require('./routes/portalRoutes');
const attendanceRoutes = require('./routes/attendanceRoutes');

const app = express();
app.use(cors());
app.use(express.json());

if (!fs.existsSync('./uploads')) fs.mkdirSync('./uploads');

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/employees', employeeRoutes);
app.use('/api/payroll', payrollRoutes);
app.use('/api/portal', portalRoutes);
app.use('/api/attendance', attendanceRoutes);

async function seedInitialData() {
    try {
        // Ensure all seeded employees have a default clock password ('123456')
        const [noClockPass] = await db.query('SELECT id FROM employees WHERE clock_password_hash IS NULL');
        if (noClockPass.length > 0) {
            const defaultClockHash = await bcrypt.hash('123456', 10);
            await db.query('UPDATE employees SET clock_password_hash = ? WHERE clock_password_hash IS NULL', [defaultClockHash]);
            console.log('Initialized default time-clock password (123456) for existing employees.');
        }

        const [rows] = await db.query('SELECT COUNT(*) as count FROM users');
        if (rows[0].count === 0) {
            const adminHash = await bcrypt.hash('admin123', 10);
            const hrHash = await bcrypt.hash('hr123', 10);
            const payHash = await bcrypt.hash('pay123', 10);

            await db.query(
                'INSERT INTO users (username, password_hash, full_name, role, allowed_modules) VALUES ?',
                [[
                    ['admin', adminHash, 'System Administrator', 'ADMIN', JSON.stringify(['employees', 'payroll', 'payslips', 'memos_manage', 'users'])],
                    ['hr_jane', hrHash, 'Jane Doe (HR Officer)', 'HR_OFFICER', JSON.stringify(['employees', 'memos_manage'])],
                    ['payroll_mark', payHash, 'Mark Santos (Payroll Officer)', 'PAYROLL_OFFICER', JSON.stringify(['payroll', 'payslips'])]
                ]]
            );

            const [empRows] = await db.query('SELECT id FROM employees WHERE emp_code = "EMP-001"');
            if (empRows.length > 0) {
                const empHash = await bcrypt.hash('emp123', 10);
                await db.query(
                    'INSERT INTO users (username, password_hash, full_name, role, employee_id, allowed_modules) VALUES (?, ?, ?, ?, ?, ?)',
                    ['emp_juan', empHash, 'Juan Dela Cruz', 'EMPLOYEE', empRows[0].id, JSON.stringify(['employee_portal'])]
                );
            }

            const [adminRow] = await db.query('SELECT id FROM users WHERE username = "admin"');
            if (adminRow.length > 0) {
                const adminId = adminRow[0].id;
                await db.query(
                    'INSERT INTO company_memos (title, category, content, due_date, posted_by) VALUES ?',
                    [[
                        ['Annual BIR Form 2316 Signing & Submission', 'COMPLIANCE', 'All employees are required to review and sign their BIR Form 2316 at the HR Office before the deadline.', '2026-12-15', adminId],
                        ['Updated SSS, PhilHealth & Pag-IBIG Contribution Schedule', 'MEMO', 'Statutory deductions reflected on your semi-monthly payslips follow the updated 2026 contribution tables.', null, adminId],
                        ['Mandatory Data Privacy & Cybersecurity Compliance', 'POLICY', 'All personnel must complete the annual Data Privacy Act acknowledgment.', '2026-11-30', adminId]
                    ]]
                );
            }
            console.log('Default officers, employee portal login, and company memos seeded.');
        }
    } catch (err) {
        console.error('Seed check error:', err.message);
    }
}

const PORT = process.env.PORT || 5000;
app.listen(PORT, async () => {
    await seedInitialData();
    console.log(`HRIS Backend API running at http://localhost:${PORT}`);
});