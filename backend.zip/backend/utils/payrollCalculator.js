function computePayroll({ basicMonthlySalary, hourlyRate, regularHours, overtimeHours, lateMinutes }) {
    const regularPay = regularHours * hourlyRate;
    const overtimePay = overtimeHours * (hourlyRate * 1.25);
    const grossPay = regularPay + overtimePay;

    const lateDeduction = (lateMinutes / 60) * hourlyRate;

    // Semi-monthly statutory shares
    const msc = Math.min(Math.max(basicMonthlySalary, 4000), 30000);
    const sss = (msc * 0.045) / 2;

    const phBase = Math.min(Math.max(basicMonthlySalary, 10000), 100000);
    const philhealth = (phBase * 0.025) / 2;

    const pagibigBase = Math.min(basicMonthlySalary, 10000);
    const pagibig = (pagibigBase * 0.02) / 2;

    // BIR TRAIN Law Semi-Monthly Withholding Tax
    const taxableIncome = Math.max(0, grossPay - lateDeduction - sss - philhealth - pagibig);
    let withholdingTax = 0;

    if (taxableIncome <= 10417) {
        withholdingTax = 0;
    } else if (taxableIncome <= 16666) {
        withholdingTax = (taxableIncome - 10417) * 0.15;
    } else if (taxableIncome <= 33332) {
        withholdingTax = 937.50 + (taxableIncome - 16667) * 0.20;
    } else if (taxableIncome <= 83332) {
        withholdingTax = 4270.70 + (taxableIncome - 33333) * 0.25;
    } else if (taxableIncome <= 333332) {
        withholdingTax = 16770.70 + (taxableIncome - 83333) * 0.30;
    } else {
        withholdingTax = 91770.70 + (taxableIncome - 333333) * 0.35;
    }

    const totalDeductions = sss + philhealth + pagibig + withholdingTax + lateDeduction;
    const netPay = Math.max(0, grossPay - totalDeductions);

    return {
        regular_pay: Number(regularPay.toFixed(2)),
        overtime_pay: Number(overtimePay.toFixed(2)),
        gross_pay: Number(grossPay.toFixed(2)),
        sss_deduction: Number(sss.toFixed(2)),
        pagibig_deduction: Number(pagibig.toFixed(2)),
        philhealth_deduction: Number(philhealth.toFixed(2)),
        withholding_tax: Number(withholdingTax.toFixed(2)),
        late_deduction: Number(lateDeduction.toFixed(2)),
        total_deductions: Number(totalDeductions.toFixed(2)),
        net_pay: Number(netPay.toFixed(2))
    };
}

module.exports = { computePayroll };