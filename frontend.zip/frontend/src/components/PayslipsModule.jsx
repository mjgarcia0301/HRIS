import React, { useState, useEffect } from 'react';
import api from '../api';

const fmt = (val) => Number(val).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export default function PayslipsModule({ initialPeriodId }) {
  const [periods, setPeriods] = useState([]);
  const [periodId, setPeriodId] = useState(initialPeriodId || '');
  const [payslips, setPayslips] = useState([]);
  const [selectedSlip, setSelectedSlip] = useState(null);

  useEffect(() => {
    api.get('/payroll/periods').then(res => {
      setPeriods(res.data);
      if (!periodId && res.data.length > 0) setPeriodId(res.data[0].id);
    });
  }, []);

  useEffect(() => {
    if (periodId) {
      api.get(`/payroll/payslips/${periodId}`).then(res => setPayslips(res.data));
    }
  }, [periodId]);

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h3>Generated Employee Payslips</h3>
        <select className="form-select w-auto" value={periodId} onChange={e => setPeriodId(e.target.value)}>
          {periods.map(p => <option key={p.id} value={p.id}>{p.period_name}</option>)}
        </select>
      </div>

      <div className="table-responsive bg-white shadow-sm rounded">
        <table className="table table-bordered table-hover mb-0">
          <thead className="table-dark">
            <tr>
              <th>Emp Code</th><th>Employee</th><th>Gross Pay</th>
              <th>SSS</th><th>Pag-IBIG</th><th>PhilHealth</th><th>W/Tax</th><th>Late</th>
              <th>Net Pay</th><th>Payslip</th>
            </tr>
          </thead>
          <tbody>
            {payslips.length === 0 ? (
              <tr><td colSpan="10" className="text-center py-3">No payslips generated for this period yet.</td></tr>
            ) : payslips.map(s => (
              <tr key={s.id}>
                <td>{s.emp_code}</td>
                <td>{s.first_name} {s.last_name}</td>
                <td>₱{fmt(s.gross_pay)}</td>
                <td>₱{fmt(s.sss_deduction)}</td>
                <td>₱{fmt(s.pagibig_deduction)}</td>
                <td>₱{fmt(s.philhealth_deduction)}</td>
                <td>₱{fmt(s.withholding_tax)}</td>
                <td>₱{fmt(s.late_deduction)}</td>
                <td className="text-success fw-bold">₱{fmt(s.net_pay)}</td>
                <td>
                  <button className="btn btn-sm btn-outline-primary" onClick={() => setSelectedSlip(s)}>
                    View / Print
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedSlip && (
        <div id="printable-payslip" className="card mt-4 p-4 border-dark shadow" style={{ maxWidth: 650 }}>
          <div className="d-flex justify-content-between border-bottom pb-2 mb-3">
            <div>
              <h4 className="mb-0">OFFICIAL PAYSLIP</h4>
              <small className="text-muted">Pay Period: {selectedSlip.period_name}</small>
            </div>
            <div className="text-end">
              <strong>{selectedSlip.emp_code}</strong><br />
              <span className="small">{selectedSlip.department} - {selectedSlip.position}</span>
            </div>
          </div>

          <div className="row mb-3 small">
            <div className="col-6">
              <strong>Employee Name:</strong> {selectedSlip.first_name} {selectedSlip.last_name}<br />
              <strong>TIN:</strong> {selectedSlip.tin_no || 'N/A'}
            </div>
            <div className="col-6">
              <strong>SSS No:</strong> {selectedSlip.sss_no || 'N/A'}<br />
              <strong>PhilHealth / Pag-IBIG:</strong> {selectedSlip.philhealth_no || 'N/A'} / {selectedSlip.pagibig_no || 'N/A'}
            </div>
          </div>

          <div className="row">
            <div className="col-6 border-end">
              <h6 className="text-primary">EARNINGS</h6>
              <div className="d-flex justify-content-between"><span>Regular Pay ({selectedSlip.regular_hours} hrs):</span><span>₱{fmt(selectedSlip.regular_pay)}</span></div>
              <div className="d-flex justify-content-between"><span>Overtime Pay ({selectedSlip.overtime_hours} hrs):</span><span>₱{fmt(selectedSlip.overtime_pay)}</span></div>
              <hr />
              <div className="d-flex justify-content-between fw-bold"><span>GROSS PAY:</span><span>₱{fmt(selectedSlip.gross_pay)}</span></div>
            </div>

            <div className="col-6">
              <h6 className="text-danger">DEDUCTIONS</h6>
              <div className="d-flex justify-content-between"><span>SSS Contribution:</span><span>₱{fmt(selectedSlip.sss_deduction)}</span></div>
              <div className="d-flex justify-content-between"><span>Pag-IBIG Contribution:</span><span>₱{fmt(selectedSlip.pagibig_deduction)}</span></div>
              <div className="d-flex justify-content-between"><span>PhilHealth Contribution:</span><span>₱{fmt(selectedSlip.philhealth_deduction)}</span></div>
              <div className="d-flex justify-content-between"><span>BIR Withholding Tax:</span><span>₱{fmt(selectedSlip.withholding_tax)}</span></div>
              <div className="d-flex justify-content-between"><span>Late ({selectedSlip.late_minutes} mins):</span><span>₱{fmt(selectedSlip.late_deduction)}</span></div>
              <hr />
              <div className="d-flex justify-content-between fw-bold"><span>TOTAL DEDUCTIONS:</span><span>₱{fmt(selectedSlip.total_deductions)}</span></div>
            </div>
          </div>

          <div className="alert alert-success mt-3 mb-2 d-flex justify-content-between align-items-center">
            <span className="fw-bold">NET TAKE-HOME PAY:</span>
            <span className="fs-4 fw-bold">₱{fmt(selectedSlip.net_pay)}</span>
          </div>

          <div className="no-print mt-2">
            <button className="btn btn-dark me-2" onClick={() => window.print()}>Print / Save as PDF</button>
            <button className="btn btn-secondary" onClick={() => setSelectedSlip(null)}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
}