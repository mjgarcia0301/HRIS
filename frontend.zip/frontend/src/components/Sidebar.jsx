import React from 'react';

export default function Sidebar({ user, activeModule, setActiveModule, onLogout }) {
  const menuItems = [
    { key: 'employee_portal', label: 'My Payslips & Memos' },
    { key: 'employees', label: 'Employee Masterfile' },
    { key: 'payroll', label: 'Auto-Payroll Upload' },
    { key: 'payslips', label: 'Generated Payslips' },
    { key: 'memos_manage', label: 'Publish Memos / Compliance' },
    { key: 'users', label: 'User & Access Control' }
  ];

  return (
    <div className="bg-dark text-white p-3 d-flex flex-column justify-content-between" style={{ width: 260, minHeight: '100vh' }}>
      <div>
        <h4 className="mb-1">HRIS Payroll</h4>
        <div className="small text-info mb-3">{user.full_name}<br />({user.role})</div>
        <hr className="border-secondary" />
        <ul className="nav nav-pills flex-column gap-2">
          {menuItems.map(item => (
            user.allowed_modules.includes(item.key) && (
              <li className="nav-item" key={item.key}>
                <button
                  className={`nav-link text-start w-100 ${activeModule === item.key ? 'active' : 'text-white'}`}
                  onClick={() => setActiveModule(item.key)}
                >
                  {item.label}
                </button>
              </li>
            )
          ))}
        </ul>
      </div>
      <button className="btn btn-outline-danger w-100" onClick={onLogout}>Logout</button>
    </div>
  );
}