import React, { useState } from 'react';
import api from '../api';

export default function Login({ onLoginSuccess, onOpenTimeClock }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post('/auth/login', { username, password });
      localStorage.setItem('hris_token', res.data.token);
      localStorage.setItem('hris_user', JSON.stringify(res.data.user));
      onLoginSuccess(res.data.user);
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed');
    }
  };

  return (
    <div className="container d-flex justify-content-center align-items-center vh-100">
      <div className="card shadow p-4" style={{ maxWidth: 440, width: '100%' }}>
        <h3 className="text-center mb-2">HRIS & Employee Portal</h3>
        <p className="text-muted text-center small">Sign in with your officer or employee credentials</p>

        {/* Dedicated Button for Separate Time-In / Time-Out Screen */}
        <button
          type="button"
          className="btn btn-dark w-100 mb-3 fw-bold"
          onClick={onOpenTimeClock}
        >
          ⏱ Open Employee Time-In / Time-Out Screen
        </button>

        <hr className="my-2" />

        {error && <div className="alert alert-danger py-2">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label className="form-label">Username</label>
            <input className="form-control" value={username} onChange={e => setUsername(e.target.value)} required />
          </div>
          <div className="mb-3">
            <label className="form-label">Password</label>
            <input type="password" className="form-control" value={password} onChange={e => setPassword(e.target.value)} required />
          </div>
          <button type="submit" className="btn btn-primary w-100">Login</button>
        </form>

        <div className="mt-3 p-2 bg-light border rounded small">
          <strong>Test Credentials:</strong><br />
          Admin: <code>admin / admin123</code> | HR: <code>hr_jane / hr123</code><br />
          Payroll: <code>payroll_mark / pay123</code> | Employee: <code>emp_juan / emp123</code>
        </div>
      </div>
    </div>
  );
}