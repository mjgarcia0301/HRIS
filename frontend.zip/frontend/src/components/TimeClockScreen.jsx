import React, { useState, useEffect } from 'react';
import api from '../api';

export default function TimeClockScreen({ onBackToLogin }) {
  const [empCode, setEmpCode] = useState('');
  const [password, setPassword] = useState('');
  const [now, setNow] = useState(new Date());
  const [feedback, setFeedback] = useState(null);
  const [recentLogs, setRecentLogs] = useState([]);

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    loadRecent();
    return () => clearInterval(timer);
  }, []);

  const loadRecent = async () => {
    try {
      const res = await api.get('/attendance/recent');
      setRecentLogs(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const handlePunch = async (action) => {
    if (!empCode || !password) {
      setFeedback({ type: 'danger', text: 'Please enter both your Employee Number and Password.' });
      return;
    }
    try {
      const res = await api.post('/attendance/punch', {
        emp_code: empCode,
        password,
        action
      });
      setFeedback({ type: 'success', text: res.data.message });
      setEmpCode('');
      setPassword('');
      loadRecent();
    } catch (err) {
      setFeedback({
        type: 'danger',
        text: err.response?.data?.message || 'Punch failed. Verify your Employee Number and Password.'
      });
    }
  };

  return (
    <div className="container py-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h3 className="mb-0">Employee Time-In / Time-Out Terminal</h3>
        <button className="btn btn-outline-dark" onClick={onBackToLogin}>
          ← Back to HRIS / Portal Login
        </button>
      </div>

      <div className="row g-4">
        {/* Left: Kiosk Punch Card */}
        <div className="col-md-5">
          <div className="card shadow p-4 border-primary">
            <div className="text-center bg-dark text-white rounded p-3 mb-3">
              <div className="small text-info">{now.toLocaleDateString('en-PH', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</div>
              <div className="display-6 fw-bold">{now.toLocaleTimeString()}</div>
            </div>

            {feedback && (
              <div className={`alert alert-${feedback.type} py-2 small`}>
                {feedback.text}
              </div>
            )}

            <div className="mb-3">
              <label className="form-label fw-bold">Employee Number</label>
              <input
                className="form-control form-control-lg"
                placeholder="e.g., EMP-001"
                value={empCode}
                onChange={e => setEmpCode(e.target.value)}
              />
            </div>

            <div className="mb-4">
              <label className="form-label fw-bold">Time-Clock Password</label>
              <input
                type="password"
                className="form-control form-control-lg"
                placeholder="Enter clock password"
                value={password}
                onChange={e => setPassword(e.target.value)}
              />
            </div>

            <div className="d-flex gap-3">
              <button
                type="button"
                className="btn btn-success btn-lg flex-fill fw-bold"
                onClick={() => handlePunch('IN')}
              >
                TIME IN
              </button>
              <button
                type="button"
                className="btn btn-danger btn-lg flex-fill fw-bold"
                onClick={() => handlePunch('OUT')}
              >
                TIME OUT
              </button>
            </div>

            <div className="mt-3 p-2 bg-light border rounded small text-muted">
              <strong>Test Kiosk Credentials:</strong><br />
              Employee No: <code>EMP-001</code>, <code>EMP-002</code>, or <code>EMP-003</code><br />
              Default Clock Password: <code>123456</code>
            </div>
          </div>
        </div>

        {/* Right: Live Attendance Log Feed */}
        <div className="col-md-7">
          <div className="card shadow-sm p-3">
            <h5>Recent Time-In / Time-Out Activity</h5>
            <div className="table-responsive">
              <table className="table table-sm table-bordered table-hover mb-0">
                <thead className="table-dark">
                  <tr>
                    <th>Emp No.</th><th>Name</th><th>Date</th>
                    <th>Time In</th><th>Time Out</th><th>Reg / OT / Late</th><th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {recentLogs.length === 0 ? (
                    <tr><td colSpan="7" className="text-center py-3">No attendance logs recorded yet.</td></tr>
                  ) : recentLogs.map(log => (
                    <tr key={log.id}>
                      <td><strong>{log.emp_code}</strong></td>
                      <td>{log.first_name} {log.last_name}</td>
                      <td>{new Date(log.work_date).toLocaleDateString()}</td>
                      <td>{new Date(log.time_in).toLocaleTimeString()}</td>
                      <td>{log.time_out ? new Date(log.time_out).toLocaleTimeString() : '-'}</td>
                      <td className="small">
                        {log.status === 'COMPLETED'
                          ? `${log.regular_hours}h / ${log.overtime_hours}h / ${log.late_minutes}m`
                          : '-'}
                      </td>
                      <td>
                        <span className={`badge ${log.status === 'COMPLETED' ? 'bg-success' : 'bg-warning text-dark'}`}>
                          {log.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}