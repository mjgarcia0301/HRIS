import React, { useState, useEffect } from 'react';
import api from '../api';

const ALL_MODULES = ['employees', 'payroll', 'payslips', 'memos_manage', 'users'];

export default function UsersModule() {
  const [users, setUsers] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [form, setForm] = useState({ username: '', password: '', full_name: '', role: 'EMPLOYEE', employee_id: '', allowed_modules: ['employee_portal'] });

  const loadData = async () => {
    const [uRes, eRes] = await Promise.all([api.get('/users'), api.get('/employees')]);
    setUsers(uRes.data);
    setEmployees(eRes.data);
  };

  useEffect(() => { loadData(); }, []);

  const toggleModule = (mod) => {
    setForm(prev => ({
      ...prev,
      allowed_modules: prev.allowed_modules.includes(mod)
        ? prev.allowed_modules.filter(m => m !== mod)
        : [...prev.allowed_modules, mod]
    }));
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    await api.post('/users', form);
    setForm({ username: '', password: '', full_name: '', role: 'EMPLOYEE', employee_id: '', allowed_modules: ['employee_portal'] });
    loadData();
  };

  return (
    <div>
      <h3>Officer & Employee Login Management</h3>
      <div className="card p-3 mb-4 shadow-sm">
        <h5>Create User Account</h5>
        <form onSubmit={handleCreate} className="row g-2 align-items-center">
          <div className="col-md-2"><input className="form-control" placeholder="Username" value={form.username} onChange={e => setForm({...form, username: e.target.value})} required /></div>
          <div className="col-md-2"><input type="password" className="form-control" placeholder="Password" value={form.password} onChange={e => setForm({...form, password: e.target.value})} required /></div>
          <div className="col-md-3"><input className="form-control" placeholder="Full Name" value={form.full_name} onChange={e => setForm({...form, full_name: e.target.value})} required /></div>
          <div className="col-md-2">
            <select className="form-select" value={form.role} onChange={e => setForm({...form, role: e.target.value, allowed_modules: e.target.value === 'EMPLOYEE' ? ['employee_portal'] : []})}>
              <option value="EMPLOYEE">EMPLOYEE</option>
              <option value="ADMIN">ADMIN</option>
              <option value="HR_OFFICER">HR_OFFICER</option>
              <option value="PAYROLL_OFFICER">PAYROLL_OFFICER</option>
            </select>
          </div>
          {form.role === 'EMPLOYEE' ? (
            <div className="col-md-3">
              <select className="form-select" value={form.employee_id} onChange={e => setForm({...form, employee_id: e.target.value})} required>
                <option value="">-- Link Employee Record --</option>
                {employees.map(emp => (
                  <option key={emp.id} value={emp.id}>{emp.emp_code} - {emp.first_name} {emp.last_name}</option>
                ))}
              </select>
            </div>
          ) : (
            <div className="col-md-3">
              {ALL_MODULES.map(mod => (
                <label key={mod} className="me-2 small">
                  <input type="checkbox" checked={form.allowed_modules.includes(mod)} onChange={() => toggleModule(mod)} /> {mod}
                </label>
              ))}
            </div>
          )}
          <div className="col-12 mt-2"><button type="submit" className="btn btn-primary btn-sm">Create Account</button></div>
        </form>
      </div>

      <table className="table table-bordered bg-white shadow-sm">
        <thead className="table-dark">
          <tr><th>Username</th><th>Full Name</th><th>Role</th><th>Linked Emp</th><th>Allowed Modules</th></tr>
        </thead>
        <tbody>
          {users.map(u => (
            <tr key={u.id}>
              <td><strong>{u.username}</strong></td>
              <td>{u.full_name}</td>
              <td>{u.role}</td>
              <td>{u.emp_code || '-'}</td>
              <td>{u.allowed_modules.map(m => <span key={m} className="badge bg-info text-dark me-1">{m}</span>)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}