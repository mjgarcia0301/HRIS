import React, { useState, useEffect } from 'react';
import api from '../api';

export default function MemosManageModule() {
  const [memos, setMemos] = useState([]);
  const [form, setForm] = useState({ title: '', category: 'COMPLIANCE', content: '', due_date: '' });
  const [msg, setMsg] = useState('');

  const loadMemos = async () => {
    const res = await api.get('/portal/memos');
    setMemos(res.data);
  };

  useEffect(() => { loadMemos(); }, []);

  const handlePublish = async (e) => {
    e.preventDefault();
    await api.post('/portal/memos', form);
    setMsg('Memo published to all employee portals.');
    setForm({ title: '', category: 'COMPLIANCE', content: '', due_date: '' });
    loadMemos();
  };

  return (
    <div>
      <h3>Company Memos & Compliance Management</h3>
      {msg && <div className="alert alert-success py-2">{msg}</div>}

      <div className="card p-3 mb-4 shadow-sm">
        <h5>Publish New Memo / Compliance Notice</h5>
        <form onSubmit={handlePublish} className="row g-2">
          <div className="col-md-5">
            <input className="form-control" placeholder="Memo / Compliance Title" value={form.title} onChange={e => setForm({...form, title: e.target.value})} required />
          </div>
          <div className="col-md-3">
            <select className="form-select" value={form.category} onChange={e => setForm({...form, category: e.target.value})}>
              <option value="COMPLIANCE">COMPLIANCE</option>
              <option value="MEMO">MEMO</option>
              <option value="POLICY">POLICY</option>
              <option value="ANNOUNCEMENT">ANNOUNCEMENT</option>
            </select>
          </div>
          <div className="col-md-4">
            <input type="date" className="form-control" title="Compliance Deadline (Optional)" value={form.due_date} onChange={e => setForm({...form, due_date: e.target.value})} />
          </div>
          <div className="col-12">
            <textarea className="form-control" rows="3" placeholder="Details, instructions, or required compliance steps..." value={form.content} onChange={e => setForm({...form, content: e.target.value})} required />
          </div>
          <div className="col-12">
            <button type="submit" className="btn btn-primary">Publish to Employees</button>
          </div>
        </form>
      </div>

      <div className="list-group shadow-sm">
        {memos.map(m => (
          <div key={m.id} className="list-group-item">
            <div className="d-flex justify-content-between">
              <strong>[{m.category}] {m.title}</strong>
              <small className="text-muted">{m.due_date ? `Due: ${new Date(m.due_date).toLocaleDateString()}` : 'No Deadline'}</small>
            </div>
            <p className="mb-1 small mt-1">{m.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
}