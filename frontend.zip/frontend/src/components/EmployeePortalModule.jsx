import React, { useState, useEffect } from 'react';
import api from '../api';

const fmt = (val) => Number(val).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export default function EmployeePortalModule() {
  const [tab, setTab] = useState('payslips');
  const [payslips, setPayslips] = useState([]);
  const [memos, setMemos] = useState([]);
  const [selectedSlip, setSelectedSlip] = useState(null);

  const loadData = async () => {
    const [slipRes, memoRes] = await Promise.all([
      api.get('/portal/my-payslips'),
      api.get('/portal/memos')
    ]);
    setPayslips(slipRes.data);
    setMemos(memoRes.data);
  };

  useEffect(() => { loadData(); }, []);

  const handleAcknowledge = async (memoId) => {
    await api.post(`/portal/memos/${memoId}/acknowledge`);
    loadData();
  };

  const pendingComplianceCount = memos.filter(m => !m.acknowledged_at).length;

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h3>Employee Self-Service Portal</h3>
        <div className="btn-group">
          <button
            className={`btn ${tab === 'payslips' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setTab('payslips')}
          >
            My Payslips ({payslips.length})
          </button>
          <button
            className={`btn ${tab === 'memos' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setTab('memos')}
          >
            Memos & Compliance{' '}
            {pendingComplianceCount > 0 && (
              <span className="badge bg-danger ms-1">{pendingComplianceCount} Pending</span>
            )}
          </button>
        </div>
      </div>

      {tab === 'payslips' && (
        <div>
          <div className="table-responsive bg-white shadow-sm rounded">
            <table className="table table-bordered table-hover mb-0">
              <thead className="table-dark">
                <tr>
                  <th>Pay Period</th><th>Gross Pay</th><th>SSS</th><th>Pag-IBIG</th>
                  <th>PhilHealth</th><th>W/Tax</th><th>Late</th><th>Net Pay</th><th>Action</th>
                </tr>
              </thead>
              <tbody>
                {payslips.length === 0 ? (
                  <tr><td colSpan="9" className="text-center py-3">No payslips available yet.</td></tr>
                ) : payslips.map(s => (
                  <tr key={s.id}>
                    <td><strong>{s.period_name}</strong></td>
                    <td>₱{fmt(s.gross_pay)}</td>
                    <td>₱{fmt(s.sss_deduction)}</td>
                    <td>₱{fmt(s.pagibig_deduction)}</td>
                    <td>₱{fmt(s.philhealth_deduction)}</td>
                    <td>₱{fmt(s.withholding_tax)}</td>
                    <td>₱{fmt(s.late_deduction)}</td>
                    <td className="text-success fw-bold">₱{fmt(s.net_pay)}</td>
                    <td>
                      <button className="btn btn-sm btn-outline-primary" onClick={() => setSelectedSlip(s)}>
                        View / Print
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {selectedSlip && (
            <div id="printable-payslip" className="card mt-4 p-4 border-dark shadow" style={{ maxWidth: 650 }}>
              <div className="d-flex justify-content-between border-bottom pb-2 mb-3">
                <div>
                  <h4 className="mb-0">OFFICIAL PAYSLIP</h4>
                  <small className="text-muted">Pay Period: {selectedSlip.period_name}</small>
                </div>
                <div className="text-end">
                  <strong>{selectedSlip.emp_code}</strong><br />
                  <span className="small">{selectedSlip.department} - {selectedSlip.position}</span>
                </div>
              </div>
              <div className="row mb-3 small">
                <div className="col-6">
                  <strong>Employee Name:</strong> {selectedSlip.first_name} {selectedSlip.last_name}<br />
                  <strong>TIN:</strong> {selectedSlip.tin_no || 'N/A'}
                </div>
                <div className="col-6">
                  <strong>SSS No:</strong> {selectedSlip.sss_no || 'N/A'}<br />
                  <strong>PhilHealth / Pag-IBIG:</strong> {selectedSlip.philhealth_no || 'N/A'} / {selectedSlip.pagibig_no || 'N/A'}
                </div>
              </div>
              <div className="row">
                <div className="col-6 border-end">
                  <h6 className="text-primary">EARNINGS</h6>
                  <div className="d-flex justify-content-between"><span>Regular Pay ({selectedSlip.regular_hours} hrs):</span><span>₱{fmt(selectedSlip.regular_pay)}</span></div>
                  <div className="d-flex justify-content-between"><span>Overtime Pay ({selectedSlip.overtime_hours} hrs):</span><span>₱{fmt(selectedSlip.overtime_pay)}</span></div>
                  <hr />
                  <div className="d-flex justify-content-between fw-bold"><span>GROSS PAY:</span><span>₱{fmt(selectedSlip.gross_pay)}</span></div>
                </div>
                <div className="col-6">
                  <h6 className="text-danger">DEDUCTIONS</h6>
                  <div className="d-flex justify-content-between"><span>SSS Contribution:</span><span>₱{fmt(selectedSlip.sss_deduction)}</span></div>
                  <div className="d-flex justify-content-between"><span>Pag-IBIG Contribution:</span><span>₱{fmt(selectedSlip.pagibig_deduction)}</span></div>
                  <div className="d-flex justify-content-between"><span>PhilHealth Contribution:</span><span>₱{fmt(selectedSlip.philhealth_deduction)}</span></div>
                  <div className="d-flex justify-content-between"><span>BIR Withholding Tax:</span><span>₱{fmt(selectedSlip.withholding_tax)}</span></div>
                  <div className="d-flex justify-content-between"><span>Late ({selectedSlip.late_minutes} mins):</span><span>₱{fmt(selectedSlip.late_deduction)}</span></div>
                  <hr />
                  <div className="d-flex justify-content-between fw-bold"><span>TOTAL DEDUCTIONS:</span><span>₱{fmt(selectedSlip.total_deductions)}</span></div>
                </div>
              </div>
              <div className="alert alert-success mt-3 mb-2 d-flex justify-content-between align-items-center">
                <span className="fw-bold">NET TAKE-HOME PAY:</span>
                <span className="fs-4 fw-bold">₱{fmt(selectedSlip.net_pay)}</span>
              </div>
              <div className="no-print mt-2">
                <button className="btn btn-dark me-2" onClick={() => window.print()}>Print / Save as PDF</button>
                <button className="btn btn-secondary" onClick={() => setSelectedSlip(null)}>Close</button>
              </div>
            </div>
          )}
        </div>
      )}

      {tab === 'memos' && (
        <div className="d-flex flex-column gap-3">
          {memos.map(memo => (
            <div key={memo.id} className={`card shadow-sm border-start border-4 ${memo.acknowledged_at ? 'border-success' : 'border-warning'}`}>
              <div className="card-body">
                <div className="d-flex justify-content-between align-items-start">
                  <div>
                    <span className="badge bg-secondary me-2">{memo.category}</span>
                    {memo.due_date && (
                      <span className="badge bg-danger">
                        Due: {new Date(memo.due_date).toLocaleDateString()}
                      </span>
                    )}
                    <h5 className="card-title mt-2 mb-1">{memo.title}</h5>
                    <small className="text-muted">Posted by {memo.author_name} on {new Date(memo.created_at).toLocaleDateString()}</small>
                  </div>

                  <div>
                    {memo.acknowledged_at ? (
                      <span className="badge bg-success p-2">
                        ✓ Complied / Acknowledged ({new Date(memo.acknowledged_at).toLocaleDateString()})
                      </span>
                    ) : (
                      <button className="btn btn-warning btn-sm fw-bold" onClick={() => handleAcknowledge(memo.id)}>
                        Acknowledge & Comply
                      </button>
                    )}
                  </div>
                </div>
                <p className="card-text mt-3 mb-0">{memo.content}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}