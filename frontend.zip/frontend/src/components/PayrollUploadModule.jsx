import React, { useState, useEffect } from 'react';
import api from '../api';

export default function PayrollUploadModule({ onPayrollProcessed }) {
  const [periods, setPeriods] = useState([]);
  const [selectedPeriod, setSelectedPeriod] = useState('');
  const [file, setFile] = useState(null);
  const [newPeriod, setNewPeriod] = useState({ period_name: '', start_date: '', end_date: '' });
  const [status, setStatus] = useState('');
  const [report, setReport] = useState(null);

  const loadPeriods = async () => {
    try {
      const res = await api.get('/payroll/periods');
      setPeriods(res.data);
      if (res.data.length > 0 && !selectedPeriod) {
        setSelectedPeriod(res.data[0].id);
      }
    } catch (err) {
      setStatus(err.response?.data?.error || 'Failed to load pay periods.');
    }
  };

  useEffect(() => { loadPeriods(); }, []);

  const handleCreatePeriod = async (e) => {
    e.preventDefault();
    try {
      await api.post('/payroll/periods', newPeriod);
      setNewPeriod({ period_name: '', start_date: '', end_date: '' });
      setStatus('Pay period created!');
      loadPeriods();
    } catch (err) {
      setStatus(err.response?.data?.error || 'Failed to create pay period.');
    }
  };

  // Generate whole Time-In / Time-Out records for the selected pay period
  const handleGenerateAttendanceReport = async () => {
    if (!selectedPeriod) return;
    try {
      const res = await api.get(`/attendance/period-report/${selectedPeriod}`);
      setReport(res.data);
      setStatus(`Generated Time-In / Time-Out records for ${res.data.period.period_name}.`);
    } catch (err) {
      setStatus(err.response?.data?.message || 'Error generating attendance report.');
    }
  };

  // Export generated Time-In / Time-Out summary as CSV file
  const exportGeneratedTimesheetCSV = () => {
    if (!report || !report.summary) return;
    const header = 'emp_code,regular_hours,overtime_hours,late_minutes\n';
    const rows = report.summary
      .map(r => `${r.emp_code},${r.regular_hours},${r.overtime_hours},${r.late_minutes}`)
      .join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `generated_timesheet_period_${selectedPeriod}.csv`;
    a.click();
  };

  // Auto-compute payroll directly from Time-In / Time-Out DB records
  const handleProcessDirectlyFromLogs = async () => {
    if (!selectedPeriod) return;
    try {
      const res = await api.post(`/attendance/process-from-logs/${selectedPeriod}`);
      setStatus(res.data.message);
      loadPeriods();
      if (onPayrollProcessed) onPayrollProcessed(selectedPeriod);
    } catch (err) {
      setStatus(err.response?.data?.message || 'No completed Time-In/Out records found for this period.');
    }
  };

  // Auto-compute payroll from uploaded CSV timesheet file
  const handleUploadCSV = async (e) => {
    e.preventDefault();
    if (!file || !selectedPeriod) return;
    const formData = new FormData();
    formData.append('timesheet', file);
    formData.append('pay_period_id', selectedPeriod);

    try {
      const res = await api.post('/payroll/upload-timesheet', formData);
      setStatus(res.data.message);
      loadPeriods();
      if (onPayrollProcessed) onPayrollProcessed(selectedPeriod);
    } catch (err) {
      setStatus(err.response?.data?.error || 'Upload failed');
    }
  };

  return (
    <div>
      <h3>Automated Payroll & Attendance Processing</h3>
      {status && <div className="alert alert-info py-2">{status}</div>}

      {/* Top Row: Generate Time-In/Out Records & Create Pay Period */}
      <div className="row g-4 mb-4">
        <div className="col-md-7">
          <div className="card p-4 shadow-sm h-100">
            <h5>1. Pay Period & Time-In / Time-Out Records</h5>
            <div className="mb-3">
              <label className="form-label fw-bold">Active Pay Period</label>
              <select
                className="form-select"
                value={selectedPeriod}
                onChange={e => { setSelectedPeriod(e.target.value); setReport(null); }}
              >
                {periods.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.period_name} ({new Date(p.start_date).toLocaleDateString()} - {new Date(p.end_date).toLocaleDateString()}) [{p.status}]
                  </option>
                ))}
              </select>
            </div>

            <div className="d-flex flex-wrap gap-2">
              <button type="button" className="btn btn-primary" onClick={handleGenerateAttendanceReport}>
                Generate Time-In & Time-Out Records
              </button>
              <button type="button" className="btn btn-success" onClick={handleProcessDirectlyFromLogs}>
                Auto-Compute Payroll Directly from Time Logs
              </button>
            </div>
            <small className="text-muted mt-2 d-block">
              Generate the full Time-In/Out attendance report for this pay period, export it as a CSV timesheet, or auto-compute payslips directly from logged punches.
            </small>
          </div>
        </div>

        <div className="col-md-5">
          <div className="card p-4 shadow-sm h-100">
            <h5>Create New Pay Period</h5>
            <form onSubmit={handleCreatePeriod}>
              <div className="mb-2">
                <input className="form-control" placeholder="Period Name (e.g., Nov 16 - Nov 30, 2026)" value={newPeriod.period_name} onChange={e => setNewPeriod({...newPeriod, period_name: e.target.value})} required />
              </div>
              <div className="row g-2 mb-3">
                <div className="col">
                  <label className="small text-muted">Start Date</label>
                  <input type="date" className="form-control" value={newPeriod.start_date} onChange={e => setNewPeriod({...newPeriod, start_date: e.target.value})} required />
                </div>
                <div className="col">
                  <label className="small text-muted">End Date</label>
                  <input type="date" className="form-control" value={newPeriod.end_date} onChange={e => setNewPeriod({...newPeriod, end_date: e.target.value})} required />
                </div>
              </div>
              <button type="submit" className="btn btn-outline-primary w-100">Add Pay Period</button>
            </form>
          </div>
        </div>
      </div>

      {/* Generated Time-In & Time-Out Records Panel */}
      {report && (
        <div className="card p-4 shadow-sm mb-4 border-primary">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h5 className="mb-0">Consolidated Time-In & Time-Out Summary ({report.period.period_name})</h5>
            <button className="btn btn-sm btn-outline-success fw-bold" onClick={exportGeneratedTimesheetCSV}>
              ⬇ Download Generated Timesheet (.CSV)
            </button>
          </div>

          <div className="table-responsive mb-4">
            <table className="table table-sm table-bordered">
              <thead className="table-dark">
                <tr>
                  <th>Emp Code</th><th>Employee Name</th><th>Department</th>
                  <th>Days Logged</th><th>Total Regular Hrs</th><th>Total OT Hrs</th><th>Total Late (mins)</th>
                </tr>
              </thead>
              <tbody>
                {report.summary.map(row => (
                  <tr key={row.emp_code}>
                    <td><strong>{row.emp_code}</strong></td>
                    <td>{row.first_name} {row.last_name}</td>
                    <td>{row.department}</td>
                    <td>{row.days_logged}</td>
                    <td>{row.regular_hours}</td>
                    <td>{row.overtime_hours}</td>
                    <td>{row.late_minutes}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <h6>Detailed Daily Time-In & Time-Out Logs</h6>
          <div className="table-responsive">
            <table className="table table-sm table-striped table-bordered mb-0">
              <thead className="table-secondary">
                <tr>
                  <th>Date</th><th>Emp Code</th><th>Name</th><th>Time In</th><th>Time Out</th><th>Reg Hrs</th><th>OT Hrs</th><th>Late (m)</th><th>Status</th>
                </tr>
              </thead>
              <tbody>
                {report.detailedLogs.length === 0 ? (
                  <tr><td colSpan="9" className="text-center py-2">No individual punch records in this date range.</td></tr>
                ) : report.detailedLogs.map(log => (
                  <tr key={log.id}>
                    <td>{new Date(log.work_date).toLocaleDateString()}</td>
                    <td>{log.emp_code}</td>
                    <td>{log.first_name} {log.last_name}</td>
                    <td>{new Date(log.time_in).toLocaleTimeString()}</td>
                    <td>{log.time_out ? new Date(log.time_out).toLocaleTimeString() : 'Still Clocked In'}</td>
                    <td>{log.regular_hours}</td>
                    <td>{log.overtime_hours}</td>
                    <td>{log.late_minutes}</td>
                    <td>{log.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Upload CSV Timesheet File Option */}
      <div className="card p-4 shadow-sm">
        <h5>2. Or Upload Timesheet File (.CSV) to Auto-Compute Payroll</h5>
        <p className="text-muted small">
          Upload the exported or external CSV timesheet (`emp_code,regular_hours,overtime_hours,late_minutes`) to automatically compute SSS, Pag-IBIG, PhilHealth, BIR Tax, and generate payslips.
        </p>
        <form onSubmit={handleUploadCSV} className="row g-2 align-items-center">
          <div className="col-md-6">
            <input type="file" accept=".csv" className="form-control" onChange={e => setFile(e.target.files[0])} required />
          </div>
          <div className="col-md-4">
            <button type="submit" className="btn btn-dark w-100">Upload CSV & Auto-Compute Payslips</button>
          </div>
        </form>
      </div>
    </div>
  );
}