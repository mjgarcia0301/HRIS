import React, { useState, useEffect } from 'react';
import api from '../api';

const fmt = (val) => Number(val).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export default function EmployeesModule() {
  const [employees, setEmployees] = useState([]);
  const [form, setForm] = useState({
    emp_code: '', first_name: '', last_name: '', email: '',
    department: '', position: '', basic_monthly_salary: '',
    sss_no: '', pagibig_no: '', philhealth_no: '', tin_no: '', clock_password: ''
  });
  const [msg, setMsg] = useState('');

  const loadEmployees = async () => {
    const res = await api.get('/employees');
    setEmployees(res.data);
  };

  useEffect(() => { loadEmployees(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post('/employees', form);
      setMsg(res.data.message);
      setForm({ emp_code: '', first_name: '', last_name: '', email: '', department: '', position: '', basic_monthly_salary: '', sss_no: '', pagibig_no: '', philhealth_no: '', tin_no: '', clock_password: '' });
      loadEmployees();
    } catch (err) {
      setMsg(err.response?.data?.error || 'Error saving employee');
    }
  };

  return (
    <div>
      <h3>Employee Masterfile</h3>
      {msg && <div className="alert alert-info py-2">{msg}</div>}

      <div className="card p-3 mb-4 shadow-sm">
        <h5>Add New Employee</h5>
        <form onSubmit={handleSubmit} className="row g-2">
          <div className="col-md-2"><input className="form-control" placeholder="Emp Code (EMP-004)" value={form.emp_code} onChange={e => setForm({...form, emp_code: e.target.value})} required /></div>
          <div className="col-md-3"><input className="form-control" placeholder="First Name" value={form.first_name} onChange={e => setForm({...form, first_name: e.target.value})} required /></div>
          <div className="col-md-3"><input className="form-control" placeholder="Last Name" value={form.last_name} onChange={e => setForm({...form, last_name: e.target.value})} required /></div>
          <div className="col-md-4"><input className="form-control" placeholder="Email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} /></div>
          <div className="col-md-3"><input className="form-control" placeholder="Department" value={form.department} onChange={e => setForm({...form, department: e.target.value})} required /></div>
          <div className="col-md-3"><input className="form-control" placeholder="Position" value={form.position} onChange={e => setForm({...form, position: e.target.value})} required /></div>
          <div className="col-md-3"><input type="number" className="form-control" placeholder="Monthly Salary (PHP)" value={form.basic_monthly_salary} onChange={e => setForm({...form, basic_monthly_salary: e.target.value})} required /></div>
          <div className="col-md-3"><input type="password" className="form-control" placeholder="Time-Clock Password (def: 123456)" value={form.clock_password} onChange={e => setForm({...form, clock_password: e.target.value})} /></div>
          <div className="col-md-3"><input className="form-control" placeholder="SSS No." value={form.sss_no} onChange={e => setForm({...form, sss_no: e.target.value})} /></div>
          <div className="col-md-3"><input className="form-control" placeholder="Pag-IBIG No." value={form.pagibig_no} onChange={e => setForm({...form, pagibig_no: e.target.value})} /></div>
          <div className="col-md-3"><input className="form-control" placeholder="PhilHealth No." value={form.philhealth_no} onChange={e => setForm({...form, philhealth_no: e.target.value})} /></div>
          <div className="col-md-3"><input className="form-control" placeholder="TIN No." value={form.tin_no} onChange={e => setForm({...form, tin_no: e.target.value})} /></div>
          <div className="col-md-3"><button className="btn btn-primary w-100" type="submit">Save Employee</button></div>
        </form>
      </div>

      <div className="table-responsive bg-white shadow-sm rounded">
        <table className="table table-bordered table-hover mb-0">
          <thead className="table-dark">
            <tr>
              <th>Code</th><th>Full Name</th><th>Department</th><th>Position</th>
              <th>Monthly Salary</th><th>Hourly Rate</th><th>Statutory IDs</th>
            </tr>
          </thead>
          <tbody>
            {employees.map(emp => (
              <tr key={emp.id}>
                <td><strong>{emp.emp_code}</strong></td>
                <td>{emp.first_name} {emp.last_name}</td>
                <td>{emp.department}</td>
                <td>{emp.position}</td>
                <td>₱{fmt(emp.basic_monthly_salary)}</td>
                <td>₱{fmt(emp.hourly_rate)}/hr</td>
                <td className="small">
                  SSS: {emp.sss_no || 'N/A'} | HDMF: {emp.pagibig_no || 'N/A'}<br />
                  PHIC: {emp.philhealth_no || 'N/A'} | TIN: {emp.tin_no || 'N/A'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}