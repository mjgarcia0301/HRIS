import React, { useState } from 'react';
import Login from './components/Login';
import TimeClockScreen from './components/TimeClockScreen';
import Sidebar from './components/Sidebar';
import EmployeesModule from './components/EmployeesModule';
import PayrollUploadModule from './components/PayrollUploadModule';
import PayslipsModule from './components/PayslipsModule';
import UsersModule from './components/UsersModule';
import EmployeePortalModule from './components/EmployeePortalModule';
import MemosManageModule from './components/MemosManageModule';

export default function App() {
  const [showTimeClock, setShowTimeClock] = useState(false);
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('hris_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [activeModule, setActiveModule] = useState(() => {
    const saved = localStorage.getItem('hris_user');
    return saved ? JSON.parse(saved).allowed_modules[0] : '';
  });
  const [lastProcessedPeriod, setLastProcessedPeriod] = useState(null);

  const handleLoginSuccess = (loggedInUser) => {
    setUser(loggedInUser);
    setActiveModule(loggedInUser.allowed_modules[0]);
  };

  const handleLogout = () => {
    localStorage.removeItem('hris_token');
    localStorage.removeItem('hris_user');
    setUser(null);
  };

  if (showTimeClock) {
    return <TimeClockScreen onBackToLogin={() => setShowTimeClock(false)} />;
  }

  if (!user) {
    return (
      <Login
        onLoginSuccess={handleLoginSuccess}
        onOpenTimeClock={() => setShowTimeClock(true)}
      />
    );
  }

  return (
    <div className="d-flex">
      <Sidebar user={user} activeModule={activeModule} setActiveModule={setActiveModule} onLogout={handleLogout} />
      <main className="flex-grow-1 p-4">
        {activeModule === 'employee_portal' && <EmployeePortalModule />}
        {activeModule === 'employees' && <EmployeesModule />}
        {activeModule === 'payroll' && (
          <PayrollUploadModule onPayrollProcessed={(pid) => { setLastProcessedPeriod(pid); setActiveModule('payslips'); }} />
        )}
        {activeModule === 'payslips' && <PayslipsModule initialPeriodId={lastProcessedPeriod} />}
        {activeModule === 'memos_manage' && <MemosManageModule />}
        {activeModule === 'users' && <UsersModule />}
      </main>
    </div>
  );
}